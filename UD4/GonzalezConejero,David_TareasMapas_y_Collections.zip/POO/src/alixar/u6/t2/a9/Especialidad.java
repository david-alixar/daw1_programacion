package alixar.u6.t2.a9;

public enum Especialidad {
    Frenos,
    Hidraulica,
    Motor
}
