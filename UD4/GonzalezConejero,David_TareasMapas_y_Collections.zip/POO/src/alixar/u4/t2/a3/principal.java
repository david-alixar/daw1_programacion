package alixar.u4.t2.a3;

public class principal {
    public static void main(String[] args) {
        PilaLista pl1 = new PilaLista();
        pl1.apilar(10);
        pl1.desapilar();
    }
}
