package alixar.u4.t1.e9.personal;

public class JefesEstacion {
    // Atributos
    private String nombre;
    private String dni;

    // Metodos
    public JefesEstacion(String nombre, String dni) {
        this.nombre = nombre;
        this.dni = dni;
    }
}