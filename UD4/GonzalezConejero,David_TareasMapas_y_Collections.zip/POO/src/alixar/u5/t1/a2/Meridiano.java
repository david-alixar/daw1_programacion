package alixar.u5.t1.a2;

public enum Meridiano {
    AM,
    PM
}
