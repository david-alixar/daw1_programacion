package com.company.entrega_1;

public enum Size {
    mediana,
    familiar
}
