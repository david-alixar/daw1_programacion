package com.company.entrega_1;

public enum ingredientes {
    Queso,
    Jamón_ibérico,
    Bacon,
    Jamón_codido,
    Carne,
    Atún
}
