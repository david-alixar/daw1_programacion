package alixar.u5.t2.a3;

public interface Figura {

    public float getArea();
}
