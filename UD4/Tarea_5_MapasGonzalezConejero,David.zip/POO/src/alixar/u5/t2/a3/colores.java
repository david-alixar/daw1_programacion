package alixar.u5.t2.a3;

public enum colores {
    azul,
    rojo,
    verde,
    amarillo

}
