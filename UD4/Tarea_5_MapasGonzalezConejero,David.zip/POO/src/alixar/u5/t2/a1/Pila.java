package alixar.u5.t2.a1;

public interface Pila {

    public void apilar(Integer numero);
    public Integer desapilar();
}
