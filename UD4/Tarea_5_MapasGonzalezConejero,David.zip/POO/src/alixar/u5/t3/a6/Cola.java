package alixar.u5.t3.a6;

public interface Cola {
    public void encolar(Integer numero);
    public Integer desencolar();
}
