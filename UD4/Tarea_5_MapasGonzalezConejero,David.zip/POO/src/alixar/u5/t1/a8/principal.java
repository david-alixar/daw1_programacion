package alixar.u5.t1.a8;

public class principal {
    public static void main(String[] args) {
        CajaCarton cc1 = new CajaCarton(60, 120, 5, 6);
        System.out.println(cc1);
    }
}
