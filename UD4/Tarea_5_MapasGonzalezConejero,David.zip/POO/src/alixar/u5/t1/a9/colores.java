package alixar.u5.t1.a9;

public enum colores {
    blanco,
    negro,
    rojo,
    azul,
    gris
}
