package alixar.u5.t1.a9;

public enum consumo_energetico {
    A,
    B,
    C,
    D,
    E,
    F
}
