package alixar.u5.t1.a5;

public enum Notas {
    DO,
    RE,
    MI,
    FA,
    SOL,
    LA,
    SI
}
