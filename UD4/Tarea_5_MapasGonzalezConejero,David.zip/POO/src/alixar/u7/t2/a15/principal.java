package alixar.u7.t2.a15;

import java.util.LinkedList;
import java.util.List;

public class principal extends LinkedList{
    public static void main(String [] args) {
        List <Integer> lista1 = new LinkedList<>();
        lista1.add(4);
        lista1.add(3);
        lista1.add(1);
        lista1.add(2);
        System.out.println(lista1);
    }
}
