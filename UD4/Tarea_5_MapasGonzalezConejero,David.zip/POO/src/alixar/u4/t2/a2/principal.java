package alixar.u4.t2.a2;

public class principal {
    public static void main(String[] args) {
        Pila pil1 = new Pila();
        pil1.apilar(10);
        pil1.desapilar();
    }
}
