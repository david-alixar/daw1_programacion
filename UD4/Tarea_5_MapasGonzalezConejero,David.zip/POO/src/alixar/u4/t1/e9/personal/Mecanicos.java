package alixar.u4.t1.e9.personal;

public class Mecanicos {
    // Atributos
    private String nombre;
    private String telefono;
    private Especialidad especialidad;

    // Metodos
   public Mecanicos(String nombre, String telefono, Especialidad especialidad) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.especialidad = especialidad;
    }
}