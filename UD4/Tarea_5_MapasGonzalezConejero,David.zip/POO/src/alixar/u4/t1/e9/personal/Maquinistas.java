package alixar.u4.t1.e9.personal;

public class Maquinistas {
    // Atributos
    private String nombre;
    private String dni;
    private double sueldo_mensual;
    private String rango;

    // Metodos
    public Maquinistas(String nombre, String dni, double sueldo_mensual, String rango) {
        this.nombre = nombre;
        this.dni = dni;
        this. sueldo_mensual = sueldo_mensual;
        this.rango = rango;
    }
}
