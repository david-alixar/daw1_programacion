package alixar.u4.t1.e9.personal;

public enum Especialidad {
    Frenos,
    Hidraulica,
    Motor
}
