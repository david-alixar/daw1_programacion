package alixar.u4.t1.a7;

public class principal {
    public static void main(String[] args) {
        Radio c1 = new Radio(80);
        c1.up(12);
        c1.display();
        c1.down(2);
        c1.display();
    }
}
