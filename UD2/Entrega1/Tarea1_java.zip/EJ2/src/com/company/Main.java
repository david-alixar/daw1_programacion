package com.company;

public class Main {

    public static void main(String[] args) {

        int n1 = 25;
        int n2 = 15;
        System.out.print("El resto de 25 y 15 es: ");
        System.out.println(n1 % n2);
    }
}
