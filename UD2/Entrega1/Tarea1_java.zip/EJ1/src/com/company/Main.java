package com.company;

public class Main {

    public static void main(String[] args) {

        int n1 = 17;
        int n2 = 2;
        System.out.print("El producto de 17 y 2 es: ");
        System.out.println(n1 * n2);
    }
}
